<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- favicon
		============================================ -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">
<!-- Google Fonts
		============================================ -->
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
<!-- Bootstrap CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<!-- Bootstrap CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
<!-- owl.carousel CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.transitions.css')); ?>">
<!-- meanmenu CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu/meanmenu.min.css')); ?>">
<!-- animate CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
<!-- normalize CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/normalize.css')); ?>">
<!-- mCustomScrollbar CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/scrollbar/jquery.mCustomScrollbar.min.css')); ?>">
<!-- jvectormap CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jvectormap/jquery-jvectormap-2.0.3.css')); ?>">
<!-- notika icon CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/notika-custom-icon.css')); ?>">
<!-- wave CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/wave/waves.min.css')); ?>">
<!-- main CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
<!-- style CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!-- responsive CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
<!-- modernizr JS
		============================================ -->
<script src="<?php echo e(asset('assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script><?php /**PATH E:\Laravel Projects\market-analyses-tool\resources\views/layouts/partials/head.blade.php ENDPATH**/ ?>