

<?php $__env->startSection('head'); ?>
<title>Market Analysis Report | Market Analysese Tool</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<!-- Start Status area -->
<div class="notika-status-area">
    <div class="container">

        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30" style="height: 150px;">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter"> <?php echo e($most_sold_product->sale_ammount); ?></span> Units</h2>
                        <h3 class="text-success"><?php echo e($most_sold_product->product_name); ?></h3>
                        <p>Most Sold Product This Week</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30" style="height: 150px;">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter"> <?php echo e($most_sold_subcategory->sale_ammount); ?></span> Units</h2>
                        <h3 class="text-primary"><?php echo e($most_sold_subcategory->subcategory_name); ?></h3>
                        <p>Most Sold Product Subcategory This Week</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="wb-traffic-inner notika-shadow sm-res-mg-t-30 tb-res-mg-t-30 dk-res-mg-t-30" style="height: 150px;">
                    <div class="website-traffic-ctn">
                        <h2><span class="counter"> <?php echo e($most_sold_category->sale_ammount); ?></span> Units</h2>
                        <h3 class="text-danger"><?php echo e($most_sold_category->category_name); ?></h3>
                        <p>Most Sold Product Category This Week</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="normal-table-list mg-t-30">
                    <h2 class="text-info" style="font-size: 21px;">Popular Products</h2>
                    <p>Most sold products of last <strong>30</strong> days.</p>
                    <div class="bsc-tbl-st">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Product</th>
                                    <th>Subcategory</th>
                                    <th>Category</th>
                                    <th>Sold Unit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $popular_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($loop->index+1); ?> </td>
                                    <td> <?php echo e($p_p->product_name); ?> </td>
                                    <td> <?php echo e($p_p->subcategory_name); ?> </td>
                                    <td> <?php echo e($p_p->category_name); ?> </td>
                                    <td> <?php echo e($p_p->sale_ammount); ?> </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- End Status area-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.full.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\market-analyses-tool\resources\views/report/index.blade.php ENDPATH**/ ?>