

<?php $__env->startSection('head'); ?>
<title>Analysis | Market Analysese Tool</title>
<!-- bootstrap select CSS
		============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-select/bootstrap-select.css')); ?>">
<?php $__env->startSection('body'); ?>

<!-- Breadcomb area Start-->
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="fa fa-file-text" aria-hidden="true"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Market Analysis </h2>
                                    <p>Get <span class="bread-ntd">Analysed Data</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <!-- <div class="breadcomb-report">
                                <button data-toggle="modal" data-target="#add_modal" data-placement="left" title="Add A Subcategory" class="btn">
                                    <i class="fa fa-plus-square" aria-hidden="true"></i> Add
                                </button>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<div class="notika-status-area">
    <div class="container">

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list">
                    <div class="cmp-tb-hd bcs-hd">
                        <h2>Select Your options</h2>
                        <p>Report are prepared based on location, category, subcategory and specific procuct. <span class="text-danger"> Left the option unselected which you don't want to include.</span></p>
                    </div>
                    <form action="" method="post" id="reportForm">
                        <?php echo csrf_field(); ?>
                        <div class="row">

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Division</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="div_id" class="select_picker" data-live-search="true">
                                            <option value="">Select Division</option>
                                            <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $div): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($div->id); ?>"><?php echo e($div->division_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Districts</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="dis_id" class="select_picker" data-live-search="true">
                                            <option value="">Select District</option>
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($dis->id); ?>"><?php echo e($dis->district_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Cities</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="city_id" class="select_picker" data-live-search="true">
                                            <option value="">Select City</option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->city_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Category</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="product_cat_id" class="select_picker" data-live-search="true">
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Subcategory</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="product_subcat_id" class="select_picker" data-live-search="true">
                                            <option value="">Select Subcategory</option>
                                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($sub_cat->id); ?>"><?php echo e($sub_cat->subcategory_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group ic-cmp-int">
                                    <label>Product</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="product_id" class="select_picker" data-live-search="true">
                                            <option value="">Select Product</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($prod->id); ?>"><?php echo e($prod->product_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <br>
                        <center>
                            <button type="submit" class="btn">
                                <i class="fa fa-plus-square" aria-hidden="true"></i> Generate
                            </button>

                        </center>
                    </form>

                </div>
            </div>
        </div>

        <br><br>
        <section id="report">
            <!-- Reports Returns here afer form submission -->
        </section>
        <br><br>

        <div class="row">

        </div>

    </div>
</div>


<!-- Data Table area End-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- bootstrap select JS
		============================================ -->
<script src="<?php echo e(asset('assets/js/bootstrap-select/bootstrap-select.js')); ?>"></script>
<!-- Charts JS
		============================================ -->
<script src="<?php echo e(asset('assets/js/charts/Chart.js')); ?>"></script>
<script>
    $('.select_picker').selectpicker();
</script>

<script>
    // this is the id of the form
    $("#reportForm").submit(function(e) {

        e.preventDefault(); // avoid to execute the actual submit of the form.


        var form = $(this);
        var url = form.attr('action');

        $.ajax({
            type: "POST",
            url: "../../report/analysis",
            data: form.serialize(), // serializes the form's elements.
            success: function(data) {

                $('#report').html(data.html);
                //console.log(Object.values(data.data));

                if (data.html.includes("barchart")) {
                    (function($) {
                        "use strict";
                        /*----------------------------------------*/
                        /*  1.  Bar Chart
                        /*----------------------------------------*/

                        var barchart_data = [];
                        Object.keys(data.data).forEach((key) => {
                            barchart_data.push(data.data[key].sale_ammount);
                        });

                        var barcharat_labels = [];
                        Object.keys(data.data).forEach((key) => {
                            barcharat_labels.push(data.data[key].month);
                        });
                        //console.log(barchart_data);

                        var ctx = document.getElementById("barchart");
                        var barchart1 = new Chart(ctx, {
                            type: 'bar',
                            data: {
                                //labels: ["Month 1", "Month 2", "Month 3", "Month 4", "Month 5", "Month 6"],
                                //labels: Object.keys(data.data),
                                labels: barcharat_labels,
                                datasets: [{
                                    label: 'Sold Unit',
                                    data: barchart_data,
                                    backgroundColor: 'rgba(0,170,136, 0.7)',
                                    borderColor: 'rgb(19,74,41)',
                                    borderWidth: 1
                                }]
                            },
                            options: {
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            beginAtZero: true
                                        }
                                    }]
                                }
                            }
                        });



                    })(jQuery);
                }

            }
        });


    });
</script>

<script>
    (function($) {
        "use strict";
        /*----------------------------------------*/
        /*  1.  Bar Chart
        /*----------------------------------------*/

        var ctx = document.getElementById("barchart1");
        var barchart1 = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["Month 1", "Month 2", "Month 3", "Month 4", "Month 5", "Month 6"],
                datasets: [{
                    label: 'Bar Chart',
                    data: [3, 25, 13, 19, 27, 35],
                    backgroundColor: 'rgb(50,205,50, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });



    })(jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.full.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel Projects\market-analyses-tool\resources\views/report/analysis.blade.php ENDPATH**/ ?>